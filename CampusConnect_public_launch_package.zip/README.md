# CampusConnect — public-launch package

This package serves the student website and FastAPI backend from one service.

## Included
- Real registration/login with JWT authentication
- Student profile data
- Opportunity search
- Course/skills/interests matching
- Saved opportunities
- Applications
- Notifications
- Employer/opportunity verification endpoints
- Reports
- SQLite persistence on a Render persistent disk
- Production Uvicorn/Gunicorn server
- Health endpoint
- Basic security headers
- Responsive public web UI

## Deploy on Render

1. Create a GitHub repository and upload this folder.
2. In Render, create a new Web Service from that GitHub repository.
3. Render can use the included `render.yaml` settings. The service runs with Gunicorn and a persistent disk for the database/uploads.
4. The first deploy gets a public `onrender.com` URL.
5. Add your custom domain in the Render service settings when ready.

Render's current docs say FastAPI can be deployed with `uvicorn main:app --host 0.0.0.0 --port $PORT`, and Render provides managed HTTPS/custom domains. For persistent relational data, Render recommends managed Postgres; this package uses a persistent disk for the first MVP launch. For a larger launch, migrate the database to Render Postgres.

## Before accepting real users
- Set a custom domain.
- Add email verification and password-reset email.
- Add rate limiting/CAPTCHA on auth and abuse endpoints.
- Restrict CORS to the real domain.
- Add a proper admin login and verification dashboard.
- Move CV/photo storage to object storage.
- Migrate SQLite to managed Postgres before multi-instance scaling.
- Add terms of service, privacy policy, contact/support and reporting procedures.
- Test backup/restore and account deletion.
